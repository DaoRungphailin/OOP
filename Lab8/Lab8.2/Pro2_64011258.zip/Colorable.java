public interface Colorable {
    
    //Methods
    public abstract void howToColor();
}