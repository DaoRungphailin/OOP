public interface Comparable<E> {
    public boolean compareTo(E o);
}